/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database.sql;

/**
 *
 * @author AVINASH GURJAR
 */
import java.awt.event.*;
class MyWindowAdaptar extends WindowAdapter{

    @Override
    public void windowClosing(WindowEvent e) {
        System.exit(0); //To change body of generated methods, choose Tools | Templates.
    }
    
}

    
    
   
